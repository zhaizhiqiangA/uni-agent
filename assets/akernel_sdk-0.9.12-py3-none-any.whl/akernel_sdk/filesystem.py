import asyncio
import os
from typing import List, Optional, Union

import yr
from yr.sandbox.sandbox import _get_gateway_host

from .types import EntryInfo


class Filesystem:
    """Client-side wrapper for filesystem operations on the remote sandbox."""

    def __init__(self, instance, gateway_addr: Optional[str] = None, instance_id: Optional[str] = None):
        self._instance = instance
        self._gateway_addr = gateway_addr
        self._instance_id = instance_id

    def read(self, path: str, format: str = "text") -> Union[str, bytes]:
        binary = format == "bytes"
        result = yr.get(self._instance.fs_read.invoke(path=path, binary=binary))
        if result.get("error"):
            raise RuntimeError(f"Failed to read {path}: {result['error']}")
        data = result["data"]
        if binary:
            return bytes.fromhex(data)
        return data

    def write(self, path: str, data: Union[str, bytes]) -> EntryInfo:
        binary = isinstance(data, bytes)
        send_data = data.hex() if binary else data
        result = yr.get(
            self._instance.fs_write.invoke(path=path, data=send_data, binary=binary)
        )
        if result.get("error"):
            raise RuntimeError(f"Failed to write {path}: {result['error']}")
        return EntryInfo(
            name=result["name"],
            path=result["path"],
            type=result["type"],
            size=result["size"],
            permissions="",
            modified_time=0.0,
        )

    def list(self, path: str, depth: int = 1) -> List[EntryInfo]:
        result = yr.get(self._instance.fs_list.invoke(path=path, depth=depth))
        if result.get("error"):
            raise RuntimeError(f"Failed to list {path}: {result['error']}")
        return [
            EntryInfo(
                name=e["name"],
                path=e["path"],
                type=e["type"],
                size=e["size"],
                permissions=e["permissions"],
                modified_time=e["modified_time"],
            )
            for e in result["entries"]
        ]

    def exists(self, path: str) -> bool:
        result = yr.get(self._instance.fs_exists.invoke(path=path))
        return result["exists"]

    def _get_connection(self):
        gateway_addr = self._gateway_addr or _get_gateway_host()
        if not gateway_addr:
            raise RuntimeError(
                "Server address is not configured. "
                "Set YR_GATEWAY_ADDRESS or YR_SERVER_ADDRESS."
            )
        host, port = gateway_addr.rsplit(":", 1)
        instance_id = self._instance_id
        if not instance_id:
            raise RuntimeError("Instance ID is not set.")
        from yr.config_manager import ConfigManager
        token = ConfigManager().auth_token
        return host, port, instance_id, token

    def _cp(self, src: str, dst: str, upload: bool) -> None:
        from yr.cli.exec import (
            copy_to_remote,
            copy_from_remote,
            copy_to_remote_streaming,
            copy_from_remote_streaming,
            choose_cp_mode,
        )

        host, port, instance_id, token = self._get_connection()
        local_path = src if upload else dst
        remote_path = dst if upload else src

        if upload and not os.path.exists(local_path):
            raise FileNotFoundError(f"Local source path not found: {local_path}")

        streaming = choose_cp_mode(local_path, remote_path, upload=upload)

        if upload:
            fn = copy_to_remote_streaming if streaming else copy_to_remote
            asyncio.run(
                fn(
                    host=host,
                    port=port,
                    instance=instance_id,
                    local_path=local_path,
                    remote_path=remote_path,
                    use_ssl=True,
                    verify_server=False,
                    token=token,
                )
            )
        else:
            fn = copy_from_remote_streaming if streaming else copy_from_remote
            asyncio.run(
                fn(
                    host=host,
                    port=port,
                    instance=instance_id,
                    remote_path=remote_path,
                    local_path=local_path,
                    use_ssl=True,
                    verify_server=False,
                    token=token,
                )
            )

    def copy_from_local(self, local_path: str, remote_path: str) -> None:
        """Copy a local file or directory **into** the sandbox.

        Args:
            local_path: Absolute or relative path on the **local** machine.
            remote_path: Absolute path inside the **sandbox**.

        Raises:
            FileNotFoundError: *local_path* does not exist.
            RuntimeError: Server address is not configured.
        """
        self._cp(local_path, remote_path, upload=True)

    def copy_to_local(self, remote_path: str, local_path: str) -> None:
        """Copy a file or directory **from** the sandbox to the local machine.

        Args:
            remote_path: Absolute path inside the **sandbox**.
            local_path: Absolute or relative path on the **local** machine.

        Raises:
            RuntimeError: Server address is not configured.
        """
        self._cp(remote_path, local_path, upload=False)

    def remove(self, path: str) -> None:
        result = yr.get(self._instance.fs_remove.invoke(path=path))
        if result.get("error"):
            raise RuntimeError(f"Failed to remove {path}: {result['error']}")

    def rename(self, old_path: str, new_path: str) -> EntryInfo:
        result = yr.get(
            self._instance.fs_rename.invoke(old_path=old_path, new_path=new_path)
        )
        if result.get("error"):
            raise RuntimeError(
                f"Failed to rename {old_path} -> {new_path}: {result['error']}"
            )
        return EntryInfo(
            name=result["name"],
            path=result["path"],
            type=result["type"],
            size=result["size"],
            permissions=result["permissions"],
            modified_time=result["modified_time"],
        )

    def make_dir(self, path: str) -> bool:
        result = yr.get(self._instance.fs_make_dir.invoke(path=path))
        if result.get("error"):
            raise RuntimeError(f"Failed to make dir {path}: {result['error']}")
        return result["created"]

    def get_info(self, path: str) -> EntryInfo:
        result = yr.get(self._instance.fs_get_info.invoke(path=path))
        if result.get("error"):
            raise RuntimeError(f"Failed to get info for {path}: {result['error']}")
        return EntryInfo(
            name=result["name"],
            path=result["path"],
            type=result["type"],
            size=result["size"],
            permissions=result["permissions"],
            modified_time=result["modified_time"],
        )
