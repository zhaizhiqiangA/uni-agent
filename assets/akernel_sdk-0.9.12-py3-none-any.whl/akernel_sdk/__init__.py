from .types import CommandResult, EntryInfo, Mount, S3Config, SandboxInfo
import os
os.environ.setdefault("YR_HTTP_CONNECTION_NUM", "2")
__all__ = [
    "PersistentBashInstance",
    "PersistentBashSandbox",
    "SimpleSandbox",
    "create_persistent",
    "Sandbox",
    "Shell",
    "Shells",
    "EntryInfo",
    "CommandResult",
    "SandboxInfo",
    "Mount",
    "S3Config",
    "CommandHandle",
    "PortForwarding",
]

# Heavy modules (sandbox.py, sandbox_api.py, yr) are lazy-loaded so that
# lightweight entry points like the ak CLI don't pay for yr import + TLS init.
_lazy_imports = {
    "PersistentBashInstance": ".sandbox",
    "PersistentBashSandbox": ".sandbox",
    "SimpleSandbox": ".sandbox",
    "create_persistent": ".sandbox",
    "ensure_yr_init": ".sandbox",
    "Sandbox": ".sandbox_api",
    "Shell": ".shell",
    "Shells": ".shell",
    "CommandHandle": ".commands",
    "PortForwarding": "yr.config",
}


def __getattr__(name):
    module_path = _lazy_imports.get(name)
    if module_path is not None:
        import importlib

        if module_path.startswith("."):
            module = importlib.import_module(module_path, __package__)
        else:
            module = importlib.import_module(module_path)
        value = getattr(module, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
