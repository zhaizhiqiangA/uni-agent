#!/usr/bin/env python3
# coding=UTF-8
"""
Standalone persistent-bash sandbox module for AKernel/SWEAgent.

Extracted from yr/sandbox/sandbox.py — only the PersistentBash* classes
needed by AKernelEnvironment. All yr SDK imports are deferred so the module
can be imported without yr installed (for testing/linting); they only matter
at runtime when an actual sandbox is created.
"""

import atexit
import os
import threading
import warnings
from typing import Any, Dict, Optional

import yr
from yr.config import PortForwarding
from yr.runtime_holder import global_runtime

from .types import YR_GET_DEFAULT_TIMEOUT, YR_GET_TIMEOUT_BUFFER

# ── yr lazy initialization ────────────────────────────────────────────────────
# yr.init() is deferred until the first sandbox is created, so that importing
# this module (e.g. for the ak CLI) does not trigger a slow TLS handshake.

_yr_initialized = False
_yr_init_lock = threading.Lock()


def ensure_yr_init():
    """Initialize yr runtime on first use. Safe to call from multiple threads."""
    global _yr_initialized
    # Fast path: flag is only set AFTER yr.init() returns, so observing True
    # means the runtime is fully ready.
    if _yr_initialized:
        return

    with _yr_init_lock:
        if _yr_initialized:
            return

        server = os.environ.get("AKERNEL_SERVER_ADDRESS", "")
        token = os.environ.get("AKERNEL_TOKEN", "")
        if not server:
            raise RuntimeError("AKERNEL_SERVER_ADDRESS is not set")
        if not token:
            raise RuntimeError("AKERNEL_TOKEN is not set")

        gateway = os.environ.get("AKERNEL_GATEWAY_ADDRESS", "").strip() or server
        os.environ.setdefault("YR_GATEWAY_ADDRESS", gateway)

        yr.init(
            yr.Config(
                server_address=server,
                auth_token=token,
                enable_tls=True,
                server_name="test",
                in_cluster=False,
                http_ioc_threads_num=8,
            )
        )
        atexit.register(yr.finalize)
        _yr_initialized = True


# ── simple (stateless) sandbox ─────────────────────────────────────────────


class SimpleSandbox:
    """
    .. deprecated::
        Use :class:`akernel_sdk.Sandbox` with ``commands.exec_persistent()`` instead.
        ``SimpleSandbox`` relies on yr RPC + ``PersistentBashInstance`` (pty inside
        the container). The new ``Sandbox`` API uses WebSocket ``/terminal/ws``
        which is lighter and does not require yr serialization of bash state.

    Same interface as PersistentBashSandbox but uses yr RPC instead of HTTP
    tunnel — no port forwarding required.

    Internally creates a PersistentBashInstance and calls run/reset via yr RPC.
    Bash state (cwd, env vars) IS maintained across exec_persistent calls
    because it's the same bash process inside the remote instance.
    """

    def __init__(
        self,
        rootfs: Optional[str] = None,
        cpu: Optional[int] = None,
        memory: Optional[int] = None,
        cpu_limit: int = 0,
        mem_limit: int = 0,
        idle_timeout: int = 300,
        env: Optional[Dict[str, str]] = None,
        name: Optional[str] = None,
        **_kwargs,
    ):
        """Create a SimpleSandbox instance.

        Args:
            rootfs: Rootfs JSON spec for the container image.
            cpu: CPU scheduling request in milli-cores.
            memory: Memory scheduling request in MB.
            cpu_limit: CPU cgroup limit in milli-cores.
                ``0`` = not set (use *cpu*); ``>0`` = explicit limit (>= *cpu*).
            mem_limit: Memory cgroup limit in MB.
                ``0`` = not set (use *memory*); ``>0`` = explicit limit (>= *memory*).
            idle_timeout: Seconds before idle sandbox is reclaimed (default 300).
            env: Environment variables to set in the sandbox.
            name: Logical name for the sandbox instance.
        """
        warnings.warn(
            "SimpleSandbox is deprecated. Use akernel_sdk.Sandbox with "
            "commands.exec_persistent() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        ensure_yr_init()
        opt = yr.InvokeOptions()
        opt.idle_timeout = idle_timeout
        opt.namespace = "akernel"
        if name is not None:
            opt.name = name
        if cpu is not None:
            opt.cpu = cpu
        if memory is not None:
            opt.memory = memory
        opt.cpu_limit = cpu_limit
        opt.mem_limit = mem_limit
        if env is not None:
            opt.env_vars = env
        if rootfs is not None:
            opt.custom_extensions["rootfs"] = rootfs

        self._instance = PersistentBashInstance.options(opt).invoke()
        # Verify instance is alive
        yr.get(self._instance.ping.invoke())

    @property
    def instance_id(self) -> str:
        """Logical instance ID (user-defined name) assigned by yr."""
        return self._instance.instance_id

    @property
    def trace_id(self) -> str:
        """Real (physical) instance ID, useful for tracing and debugging."""
        logical_id = self._instance.instance_id
        return global_runtime.get_runtime().get_real_instance_id(logical_id)

    @property
    def id(self) -> str:
        """Real (physical) instance ID, consistent with ak list output."""
        return self.trace_id

    def exec_persistent(self, command: str, timeout: int = 60) -> Dict[str, Any]:
        """Execute command in persistent bash via yr RPC."""
        rpc_timeout = max(timeout + YR_GET_TIMEOUT_BUFFER, YR_GET_DEFAULT_TIMEOUT)
        return yr.get(
            self._instance.run.invoke(command=command, timeout=timeout),
            timeout=rpc_timeout,
        )

    def new_terminal(self) -> Dict[str, Any]:
        """Reset bash session via yr RPC."""
        return yr.get(self._instance.reset.invoke())

    def health_check(self, timeout: int = 10) -> bool:
        """Check if the remote instance is alive via yr RPC ping (bypasses bash)."""
        try:
            result = yr.get(self._instance.ping.invoke(), timeout=timeout)
            return result.get("status") == "ok"
        except Exception:
            return False

    def terminate(self) -> None:
        self._instance.terminate()

    def __del__(self):
        try:
            self.terminate()
        except Exception:
            pass


_PBASH_SENTINEL = "PBASH_SENTINEL"
_PBASH_PORT = 8080


# ── helpers ────────────────────────────────────────────────────────────────


def _get_gateway_host() -> str:
    """Get Gateway host from YR_GATEWAY_ADDRESS or YR_SERVER_ADDRESS."""
    host = os.environ.get("YR_GATEWAY_ADDRESS", "").strip()
    if host:
        return host
    return os.environ.get("YR_SERVER_ADDRESS", "").strip()


# ── remote instance (serialized by yr and sent to sandbox container) ───────


@yr.instance
class PersistentBashInstance:
    """
    yr instance that runs a persistent pty bash + HTTP server inside the
    remote sandbox container.

    yr serializes this class definition and sends it to the container, so
    the bash state is maintained across calls without needing skip_serialize.

    HTTP API (on _PBASH_PORT):
      POST /run          {"command": str, "timeout": int}
      POST /new_terminal {}
      GET  /health
    """

    def __init__(self, port: int = _PBASH_PORT):
        import errno
        import fcntl
        import json
        import os
        import pty
        import re
        import select
        import signal
        import subprocess
        import threading
        import time
        from http.server import BaseHTTPRequestHandler, HTTPServer

        self._port = port
        self._sentinel = _PBASH_SENTINEL
        self._bash_lock = threading.Lock()

        # ── start persistent bash ──────────────────────────────────
        master_fd, slave_fd = pty.openpty()
        self._bash_proc = subprocess.Popen(
            ["bash", "--norc", "--noprofile"],
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
            preexec_fn=os.setsid,
        )
        os.close(slave_fd)
        self._master_fd = master_fd
        flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
        fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        self._drain(0.5)

        # ── start HTTP server in a daemon thread ───────────────────
        instance = self

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                pass  # silence access log

            def _send_json(self, data, status=200):
                body = json.dumps(data).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def _read_body(self):
                n = int(self.headers.get("Content-Length", 0))
                return json.loads(self.rfile.read(n)) if n else {}

            def do_GET(self):
                if self.path == "/health":
                    self._send_json({"status": "ok", "port": instance._port})
                else:
                    self._send_json({"error": "not found"}, 404)

            def do_POST(self):
                body = self._read_body()
                if self.path == "/run":
                    cmd = body.get("command", body.get("cmds", ""))
                    timeout = int(body.get("timeout", 60))
                    self._send_json(instance._run_bash(cmd, timeout))
                elif self.path == "/new_terminal":
                    instance._reset_bash()
                    self._send_json({"returncode": 0, "stdout": "", "stderr": ""})
                else:
                    self._send_json({"error": f"unknown: {self.path}"}, 404)

        server = HTTPServer(("0.0.0.0", port), _Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()

    # ── helpers (imports re-done to survive yr serialization) ──────────────

    def _drain(self, timeout: float = 0.2) -> str:
        import os
        import select
        import time

        buf = b""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                ready, _, _ = select.select([self._master_fd], [], [], 0.05)
                if ready:
                    buf += os.read(self._master_fd, 4096)
            except OSError:
                break
        return buf.decode("utf-8", errors="replace")

    def _parse_bash_output(self, text: str, sentinel: str) -> Optional[dict]:
        """Parse pty output to extract command result, filtering sentinel echo and noise."""
        import re

        m = re.search(rf"{re.escape(sentinel)}_(\d+)\r?\n", text)
        if not m:
            return None
        rc = int(m.group(1))
        raw = text[: m.start()]
        parts = raw.split("\n", 1)
        output = parts[1].rstrip("\r\n") if len(parts) > 1 else ""
        output = re.sub(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])", "", output)
        output = output.replace("\r\n", "\n").replace("\r", "\n")
        output = "\n".join(
            ln
            for ln in output.split("\n")
            if not re.match(r"[\w.-]+[#$]\s", ln) and sentinel not in ln
        )
        output = output.strip("\n")
        return {"returncode": rc, "stdout": output, "stderr": ""}

    def _run_bash(self, command: str, timeout: int = 60) -> dict:
        import errno
        import os
        import re
        import select
        import signal
        import time

        sentinel = f"{self._sentinel}_{id(command) & 0xFFFFFFFF}"
        wrapped = f"{command}\necho '{sentinel}'_$?\n"

        with self._bash_lock:
            try:
                os.write(self._master_fd, wrapped.encode())
            except OSError as e:
                return {"returncode": -1, "stdout": "", "stderr": str(e)}

            buf = b""
            deadline = time.time() + timeout
            while time.time() < deadline:
                try:
                    ready, _, _ = select.select(
                        [self._master_fd],
                        [],
                        [],
                        min(0.1, max(0.0, deadline - time.time())),
                    )
                    if ready:
                        chunk = os.read(self._master_fd, 4096)
                        if chunk:
                            buf += chunk
                            text = buf.decode("utf-8", errors="replace")
                            result = self._parse_bash_output(text, sentinel)
                            if result is not None:
                                return result
                except OSError as e:
                    if e.errno == errno.EIO:
                        break
                    raise

        # Timed out — check if bash died (e.g. user ran `exit`)
        if self._bash_proc.poll() is not None:
            self._reset_bash()
            return {"returncode": 0, "stdout": "", "stderr": ""}

        # Still alive — interrupt foreground process group
        try:
            os.killpg(os.getpgid(self._bash_proc.pid), signal.SIGINT)
        except Exception:
            pass
        try:
            os.write(self._master_fd, b"\n")
            self._drain(0.5)
        except Exception:
            pass
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": f"Command timed out after {timeout}s",
        }

    def _reset_bash(self) -> None:
        import fcntl
        import os
        import pty
        import subprocess

        with self._bash_lock:
            try:
                self._bash_proc.kill()
                self._bash_proc.wait(timeout=5)
            except Exception:
                pass
            try:
                os.close(self._master_fd)
            except Exception:
                pass

        master_fd, slave_fd = pty.openpty()
        self._bash_proc = subprocess.Popen(
            ["bash", "--norc", "--noprofile"],
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
            preexec_fn=os.setsid,
        )
        os.close(slave_fd)
        self._master_fd = master_fd
        flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
        fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        self._drain(0.5)

    def run(self, command: str, timeout: int = 60) -> dict:
        """Execute command via yr RPC (no port forwarding needed)."""
        return self._run_bash(command, timeout)

    def reset(self) -> dict:
        """Reset bash session via yr RPC."""
        self._reset_bash()
        return {"returncode": 0, "stdout": "", "stderr": ""}

    def ping(self) -> dict:
        """Health check — confirms instance is alive and HTTP server is running."""
        return {"status": "ok", "port": self._port}


# ── client-side wrapper ────────────────────────────────────────────────────


class PersistentBashSandbox:
    """
    .. deprecated::
        Use :class:`akernel_sdk.Sandbox` with ``commands.exec_persistent()`` instead.
        ``PersistentBashSandbox`` relies on yr serialization + HTTP port forwarding.
        The new ``Sandbox`` API uses WebSocket ``/terminal/ws`` which is lighter.

    Client-side wrapper for PersistentBashInstance.

    PersistentBashInstance is serialized by yr and run in the remote sandbox
    container (with the desired rootfs/image). Communication is via HTTPS
    tunnel URL (yr port forwarding).

    Usage:
        sb = PersistentBashSandbox(rootfs=json.dumps({...}), cpu=4000, memory=8192)
        result = sb.exec_persistent("cd /testbed && pwd")
        sb.new_terminal()
        sb.terminate()
    """

    BASH_PORT = _PBASH_PORT

    def __init__(
        self,
        rootfs: Optional[str] = None,
        cpu: Optional[int] = None,
        memory: Optional[int] = None,
        cpu_limit: int = 0,
        mem_limit: int = 0,
        idle_timeout: int = 300,
        env: Optional[Dict[str, str]] = None,
        name: Optional[str] = None,
    ):
        """Create a PersistentBashSandbox instance.

        Args:
            rootfs: Rootfs JSON spec for the container image.
            cpu: CPU scheduling request in milli-cores.
            memory: Memory scheduling request in MB.
            cpu_limit: CPU cgroup limit in milli-cores.
                ``0`` = not set (use *cpu*); ``-1`` = unlimited; ``>0`` = explicit limit (>= *cpu*).
            mem_limit: Memory cgroup limit in MB.
                ``0`` = not set (use *memory*); ``-1`` = unlimited; ``>0`` = explicit limit (>= *memory*).
            idle_timeout: Seconds before idle sandbox is reclaimed (default 300).
            env: Environment variables to set in the sandbox.
            name: Logical name for the sandbox instance.
        """
        warnings.warn(
            "PersistentBashSandbox is deprecated. Use akernel_sdk.Sandbox with "
            "commands.exec_persistent() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        ensure_yr_init()
        opt = yr.InvokeOptions()
        opt.idle_timeout = idle_timeout
        opt.namespace = "akernel"
        if name is not None:
            opt.name = name
        if cpu is not None:
            opt.cpu = cpu
        if memory is not None:
            opt.memory = memory
        opt.cpu_limit = cpu_limit
        opt.mem_limit = mem_limit
        if env is not None:
            opt.env_vars = env
        if rootfs is not None:
            opt.custom_extensions["rootfs"] = rootfs
        opt.port_forwardings = [PortForwarding(port=self.BASH_PORT, protocol="TCP")]

        self._instance = PersistentBashInstance.options(opt).invoke(port=self.BASH_PORT)

        # Verify instance is alive (also waits for __init__ to complete)
        result = yr.get(self._instance.ping.invoke())
        if result.get("status") != "ok":
            raise RuntimeError("PersistentBashInstance failed to start")

        # Build tunnel URL
        logical_id = self._instance.instance_id
        real_id = global_runtime.get_runtime().get_real_instance_id(logical_id)
        gateway = _get_gateway_host()
        if not gateway:
            raise ValueError(
                "YR_GATEWAY_ADDRESS or YR_SERVER_ADDRESS must be set for tunnel URL"
            )
        self._base_url = f"https://{gateway}/{real_id}/{self.BASH_PORT}"

        import ssl

        self._ssl_ctx = ssl.create_default_context()
        self._ssl_ctx.check_hostname = False
        self._ssl_ctx.verify_mode = ssl.CERT_NONE

    def _http_post(self, path: str, payload: dict, timeout: int = 65) -> dict:
        import json
        import urllib.request

        url = self._base_url + path
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, context=self._ssl_ctx, timeout=timeout) as r:
            return json.loads(r.read())

    def exec_persistent(self, command: str, timeout: int = 60) -> Dict[str, Any]:
        """Execute command in the persistent bash session (blocking HTTP call)."""
        return self._http_post(
            "/run", {"command": command, "timeout": timeout}, timeout=timeout + 5
        )

    def new_terminal(self) -> Dict[str, Any]:
        """Reset the persistent bash session."""
        return self._http_post("/new_terminal", {}, timeout=30)

    def terminate(self) -> None:
        """Terminate the remote instance."""
        self._instance.terminate()

    def __del__(self):
        try:
            self.terminate()
        except Exception:
            pass


# ── convenience factory ────────────────────────────────────────────────────


def create_persistent(
    rootfs: Optional[str] = None,
    cpu: Optional[int] = None,
    memory: Optional[int] = None,
    idle_timeout: int = 300,
    env: Optional[Dict[str, str]] = None,
    name: Optional[str] = None,
) -> Optional[PersistentBashSandbox]:
    """
    .. deprecated::
        Use :class:`akernel_sdk.Sandbox` with ``commands.exec_persistent()`` instead.

    Convenience factory for PersistentBashSandbox.

    Returns None on failure (same contract as yr.sandbox.create()).
    """
    warnings.warn(
        "create_persistent is deprecated. Use akernel_sdk.Sandbox with "
        "commands.exec_persistent() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    try:
        return PersistentBashSandbox(
            rootfs=rootfs,
            cpu=cpu,
            memory=memory,
            idle_timeout=idle_timeout,
            env=env,
            name=name,
        )
    except Exception:
        return None
