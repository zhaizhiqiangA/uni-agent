"""AKernel SDK CLI — ak command for managing sandbox instances."""

import argparse
import asyncio
import json
import os
import ssl
import sys
from urllib import request
from urllib.error import HTTPError, URLError
from urllib.parse import quote

DEFAULT_COMMAND = "/bin/bash"

# Global state for terminal resize handling
_resize_queue = asyncio.Queue()
_event_loop = None


def _get_server_config():
    """Get server address and token from environment variables."""
    server = os.environ.get("AKERNEL_SERVER_ADDRESS", "").strip()
    token = os.environ.get("AKERNEL_TOKEN", "").strip()
    if not server:
        print("Error: AKERNEL_SERVER_ADDRESS is not set", file=sys.stderr)
        sys.exit(1)
    if not token:
        print("Error: AKERNEL_TOKEN is not set", file=sys.stderr)
        sys.exit(1)
    return server, token


def _create_ssl_context() -> ssl.SSLContext:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def _make_get_request(url: str, token: str, ssl_context: ssl.SSLContext) -> dict:
    req = request.Request(url, method="GET", headers={"X-AUTH": token})
    try:
        with request.urlopen(req, context=ssl_context) as response:
            return {"status": response.status, "body": response.read().decode("utf-8")}
    except HTTPError as e:
        return {"status": e.code, "body": e.read().decode("utf-8")}
    except URLError as e:
        print(f"Error: failed to send request: {e}", file=sys.stderr)
        sys.exit(1)


def handle_list(quiet: bool = False):
    """List all running instances.

    When *quiet* is set, print only instance IDs (one per line) so the output
    pipes cleanly into ``xargs ak delete``.
    """
    server, token = _get_server_config()
    ssl_context = _create_ssl_context()

    list_url = f"https://{server}/api/instances?tenant_id=default"
    result = _make_get_request(list_url, token, ssl_context)

    if result["status"] != 200:
        print(f"Error: server returned status {result['status']}", file=sys.stderr)
        print(f"Response: {result['body']}", file=sys.stderr)
        sys.exit(1)

    try:
        instances = json.loads(result["body"])
    except json.JSONDecodeError as e:
        print(f"Error: failed to parse response: {e}", file=sys.stderr)
        sys.exit(1)

    running = [inst for inst in instances if inst.get("status") == "running"]

    if quiet:
        for inst in running:
            inst_id = inst.get("id", "")
            if inst_id:
                print(inst_id)
        return

    if not running:
        print("No running instances found.")
        return

    # Print header
    id_width = max(len(inst.get("id", "")) for inst in running)
    id_width = max(id_width, 2)

    print(f"{'ID':<{id_width}}  STATUS")
    print(f"{'-' * id_width}  ------")
    for inst in running:
        inst_id = inst.get("id", "unknown")
        status = inst.get("status", "unknown")
        print(f"{inst_id:<{id_width}}  {status}")


def handle_delete(instance_ids):
    """Terminate one or more sandbox instances via yr runtime.

    yr is initialized once, then ``yr.kill_instance`` is called per ID so
    batch deletes amortize the TLS/init cost. A failure on any single ID is
    reported to stderr and the rest continue; exits non-zero if any failed.
    """
    from .sandbox import ensure_yr_init

    import yr

    ensure_yr_init()

    failed = []
    for instance_id in instance_ids:
        try:
            yr.kill_instance(instance_id)
            print(f"deleted: {instance_id}")
        except Exception as e:
            print(f"failed to delete {instance_id}: {e}", file=sys.stderr)
            failed.append(instance_id)

    if failed:
        sys.exit(1)


class _RawTerminal:
    """Context manager for raw terminal mode."""

    def __init__(self, fd):
        import termios

        self.fd = fd
        self.old = termios.tcgetattr(fd)

    def __enter__(self):
        import tty

        tty.setraw(self.fd)
        return self

    def __exit__(self, *exc):
        import termios

        termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)


async def _read_stdin(ws, should_exit):
    import select

    from websockets.exceptions import ConnectionClosed

    loop = asyncio.get_running_loop()
    stdin_fd = sys.stdin.fileno()

    def _read():
        try:
            ready, _, _ = select.select([stdin_fd], [], [], 0.1)
            if not ready:
                return None
            data = os.read(stdin_fd, 4096)
            return data if data else b""
        except (OSError, IOError):
            return b""

    try:
        while not should_exit.is_set():
            data = await loop.run_in_executor(None, _read)
            if data == b"":
                break
            if data is None:
                continue
            # Ctrl+] to disconnect
            if b"\x1d" in data:
                print(
                    "\n[Escape sequence detected, disconnecting...]",
                    file=sys.stderr,
                )
                should_exit.set()
                break
            await ws.send(data)
    except ConnectionClosed:
        pass
    finally:
        should_exit.set()


async def _read_websocket(ws, should_exit):
    try:
        async for message in ws:
            if should_exit.is_set():
                break
            if isinstance(message, bytes):
                sys.stdout.buffer.write(message)
                sys.stdout.buffer.flush()
    except Exception:
        pass
    finally:
        should_exit.set()


def _on_terminal_resize():
    import shutil

    try:
        size = shutil.get_terminal_size()
        _resize_queue.put_nowait((size.lines, size.columns))
    except Exception:
        pass


async def _resize_handler_task(ws):
    while True:
        try:
            rows, cols = await _resize_queue.get()
            await ws.send(f"RESIZE:{cols}:{rows}")
        except asyncio.CancelledError:
            break
        except Exception:
            pass


async def _run_exec(instance_id: str, command: str, server: str, token: str):
    import shutil
    import signal

    import websockets

    global _event_loop
    _event_loop = asyncio.get_running_loop()

    ssl_context = _create_ssl_context()

    try:
        terminal_size = shutil.get_terminal_size()
        rows, cols = terminal_size.lines, terminal_size.columns
    except Exception:
        rows, cols = 24, 80

    encoded_command = quote(command)
    uri = (
        f"wss://{server}/terminal/ws?"
        f"instance={instance_id}&"
        f"command={encoded_command}&"
        f"tenant_id=default&"
        f"token={token}&"
        f"tty=true&"
        f"rows={rows}&"
        f"cols={cols}"
    )

    print(f"Connecting to {instance_id}...", file=sys.stderr)
    print("Press Ctrl+] to disconnect", file=sys.stderr)

    _event_loop.add_signal_handler(signal.SIGWINCH, _on_terminal_resize)

    try:
        async with websockets.connect(
            uri, ssl=ssl_context, ping_interval=20, ping_timeout=10
        ) as ws:
            should_exit = asyncio.Event()
            await ws.send(f"RESIZE:{cols}:{rows}")

            with _RawTerminal(sys.stdin.fileno()):
                done, pending = await asyncio.wait(
                    [
                        asyncio.create_task(_read_stdin(ws, should_exit)),
                        asyncio.create_task(_read_websocket(ws, should_exit)),
                        asyncio.create_task(_resize_handler_task(ws)),
                    ],
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
    except KeyboardInterrupt:
        print("\n[Interrupted]", file=sys.stderr)
    except Exception as e:
        print(f"\nConnection error: {e}", file=sys.stderr)
    finally:
        if _event_loop is not None:
            _event_loop.remove_signal_handler(signal.SIGWINCH)
        _event_loop = None


def handle_exec(instance_id: str, command: str):
    """Execute interactive terminal in a sandbox instance."""
    server, token = _get_server_config()
    try:
        asyncio.run(_run_exec(instance_id, command, server, token))
    except KeyboardInterrupt:
        print("\nDisconnected", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(prog="ak", description="AKernel SDK CLI")
    sub = parser.add_subparsers(dest="command")

    list_parser = sub.add_parser("list", help="List all running instances")
    list_parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Print only instance IDs (suitable for `ak list -q | xargs ak delete`)",
    )

    exec_parser = sub.add_parser("exec", help="Execute command in a sandbox instance")
    exec_parser.add_argument("instance_id", help="Instance ID")
    exec_parser.add_argument(
        "cmdline",
        nargs="*",
        default=None,
        help="Command to execute (default: /bin/bash)",
    )

    delete_parser = sub.add_parser(
        "delete", help="Terminate one or more sandbox instances"
    )
    delete_parser.add_argument(
        "instance_ids",
        nargs="+",
        help="Instance IDs to delete (one or more)",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "list":
        handle_list(quiet=args.quiet)
    elif args.command == "exec":
        cmd = " ".join(args.cmdline) if args.cmdline else DEFAULT_COMMAND
        handle_exec(args.instance_id, cmd)
    elif args.command == "delete":
        handle_delete(args.instance_ids)


if __name__ == "__main__":
    main()
