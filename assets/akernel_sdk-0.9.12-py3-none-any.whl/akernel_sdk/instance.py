import yr


@yr.instance
class _SandboxInstance:
    """Remote sandbox instance running inside the container.

    All methods use local imports to survive yr serialization.
    Returns dicts for yr RPC serialization compatibility.
    """

    def __init__(self, cwd=None):
        import os
        import tempfile

        if cwd is not None:
            os.makedirs(cwd, exist_ok=True)
            self._cwd = cwd
        else:
            self._cwd = tempfile.mkdtemp(prefix="sandbox_")
        self._procs = {}
        self._bash_sessions = {}

    # ── filesystem methods ─────────────────────────────────────────────

    def fs_read(self, path, binary=False):
        try:
            mode = "rb" if binary else "r"
            with open(path, mode) as f:
                data = f.read()
            if binary:
                return {"data": data.hex(), "error": None}
            return {"data": data, "error": None}
        except Exception as e:
            return {"data": None, "error": str(e)}

    def fs_write(self, path, data, binary=False):
        import os

        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            if binary:
                with open(path, "wb") as f:
                    f.write(bytes.fromhex(data))
            else:
                with open(path, "w") as f:
                    f.write(data)
            st = os.stat(path)
            return {
                "path": path,
                "name": os.path.basename(path),
                "type": "file",
                "size": st.st_size,
                "error": None,
            }
        except Exception as e:
            return {"path": path, "name": "", "type": "", "size": 0, "error": str(e)}

    def fs_list(self, path, depth=1):
        import os
        import stat as stat_mod

        def _scan(p, current_depth):
            entries = []
            try:
                for entry in os.scandir(p):
                    try:
                        st = entry.stat(follow_symlinks=False)
                        if entry.is_symlink():
                            etype = "symlink"
                        elif entry.is_dir(follow_symlinks=False):
                            etype = "dir"
                        else:
                            etype = "file"
                        entries.append(
                            {
                                "name": entry.name,
                                "path": entry.path,
                                "type": etype,
                                "size": st.st_size,
                                "permissions": stat_mod.filemode(st.st_mode)[1:],
                                "modified_time": st.st_mtime,
                            }
                        )
                        if etype == "dir" and current_depth < depth:
                            entries.extend(_scan(entry.path, current_depth + 1))
                    except OSError:
                        continue
            except OSError:
                pass
            return entries

        return {"entries": _scan(path, 1), "error": None}

    def fs_exists(self, path):
        import os

        return {"exists": os.path.exists(path)}

    def fs_remove(self, path):
        import os
        import shutil

        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            return {"error": None}
        except Exception as e:
            return {"error": str(e)}

    def fs_rename(self, old_path, new_path):
        import os
        import stat as stat_mod

        try:
            os.makedirs(os.path.dirname(new_path) or ".", exist_ok=True)
            os.rename(old_path, new_path)
            st = os.stat(new_path)
            if os.path.isdir(new_path):
                etype = "dir"
            elif os.path.islink(new_path):
                etype = "symlink"
            else:
                etype = "file"
            return {
                "name": os.path.basename(new_path),
                "path": new_path,
                "type": etype,
                "size": st.st_size,
                "permissions": stat_mod.filemode(st.st_mode)[1:],
                "modified_time": st.st_mtime,
                "error": None,
            }
        except Exception as e:
            return {"error": str(e)}

    def fs_make_dir(self, path):
        import os

        try:
            existed = os.path.exists(path)
            os.makedirs(path, exist_ok=True)
            return {"created": not existed, "error": None}
        except Exception as e:
            return {"created": False, "error": str(e)}

    def fs_get_info(self, path):
        import os
        import stat as stat_mod

        try:
            st = os.stat(path)
            if os.path.islink(path):
                etype = "symlink"
            elif os.path.isdir(path):
                etype = "dir"
            else:
                etype = "file"
            return {
                "name": os.path.basename(path),
                "path": path,
                "type": etype,
                "size": st.st_size,
                "permissions": stat_mod.filemode(st.st_mode)[1:],
                "modified_time": st.st_mtime,
                "error": None,
            }
        except Exception as e:
            return {"error": str(e)}

    # ── command execution methods ──────────────────────────────────────

    def cmd_run(self, cmd, envs=None, cwd=None, timeout=60):
        import os
        import subprocess

        try:
            env = os.environ.copy()
            if envs:
                env.update(envs)
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd or self._cwd,
                env=env,
                timeout=timeout,
                # Foreground one-shot commands cannot receive stdin (no handle
                # is returned), so detach stdin to /dev/null. Otherwise the
                # child inherits the runtime's stdin and any interactive
                # prompt (e.g. apt/debconf tzdata) blocks forever on read().
                stdin=subprocess.DEVNULL,
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            }
        except subprocess.TimeoutExpired as e:
            return {
                "stdout": e.stdout.decode() if e.stdout else "",
                "stderr": f"Command timed out after {timeout} seconds",
                "exit_code": -1,
            }
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def cmd_start(self, cmd, envs=None, cwd=None, want_stdin=False):
        import os
        import subprocess
        import threading

        try:
            env = os.environ.copy()
            if envs:
                env.update(envs)
            # Default stdin to /dev/null: an open PIPE with no writer never
            # reaches EOF, so any interactive prompt (apt/debconf tzdata, etc.)
            # blocks forever on read(). Callers that need send_stdin must opt
            # in via want_stdin=True.
            proc = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.PIPE if want_stdin else subprocess.DEVNULL,
                cwd=cwd or self._cwd,
                env=env,
            )

            stdout_chunks = []
            stderr_chunks = []

            def _read_stream(stream, chunks):
                try:
                    while True:
                        data = stream.read(4096)
                        if not data:
                            break
                        chunks.append(data)
                except Exception:
                    pass

            stdout_thread = threading.Thread(
                target=_read_stream, args=(proc.stdout, stdout_chunks), daemon=True
            )
            stderr_thread = threading.Thread(
                target=_read_stream, args=(proc.stderr, stderr_chunks), daemon=True
            )
            stdout_thread.start()
            stderr_thread.start()

            self._procs[proc.pid] = {
                "proc": proc,
                "cmd": cmd,
                "stdout_chunks": stdout_chunks,
                "stderr_chunks": stderr_chunks,
                "stdout_thread": stdout_thread,
                "stderr_thread": stderr_thread,
            }
            return {"pid": proc.pid, "error": None}
        except Exception as e:
            return {"pid": -1, "error": str(e)}

    def _collect_proc_output(self, entry):
        """Wait for reader threads and return collected stdout/stderr."""
        entry["stdout_thread"].join(timeout=5)
        entry["stderr_thread"].join(timeout=5)
        stdout = b"".join(entry["stdout_chunks"]).decode("utf-8", errors="replace")
        stderr = b"".join(entry["stderr_chunks"]).decode("utf-8", errors="replace")
        return stdout, stderr

    def cmd_wait(self, pid, timeout=None):
        try:
            entry = self._procs.get(pid)
            if entry is None:
                return {
                    "stdout": "",
                    "stderr": f"No process with pid {pid}",
                    "exit_code": -1,
                }
            proc = entry["proc"]
            try:
                proc.wait(timeout=timeout)
            except Exception as e:
                return {"stdout": "", "stderr": str(e), "exit_code": -1}
            stdout, stderr = self._collect_proc_output(entry)
            return {
                "stdout": stdout,
                "stderr": stderr,
                "exit_code": proc.returncode,
            }
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def cmd_poll(self, pid, wait_timeout=10):
        """Short-poll for process completion. Returns within wait_timeout seconds.

        Uses a background waiter thread so that the poll reliably times out
        even when the process is in uninterruptible sleep (D state), e.g.
        blocked on a FUSE page fault.
        """
        import threading

        try:
            entry = self._procs.get(pid)
            if entry is None:
                return {"status": "error", "error": f"No process with pid {pid}"}
            proc = entry["proc"]

            # Lazily start a background thread that does proc.wait() and
            # signals an event on completion.  This avoids blocking the RPC
            # handler thread when waitpid() hangs in D-state.
            if "_wait_event" not in entry:
                event = threading.Event()
                entry["_wait_event"] = event

                def _waiter():
                    try:
                        proc.wait()
                    except Exception:
                        pass
                    event.set()

                t = threading.Thread(target=_waiter, daemon=True)
                t.start()

            if entry["_wait_event"].wait(timeout=wait_timeout):
                stdout, stderr = self._collect_proc_output(entry)
                return {
                    "status": "done",
                    "stdout": stdout,
                    "stderr": stderr,
                    "exit_code": proc.returncode,
                }
            return {"status": "running"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def cmd_list(self):
        processes = []
        for pid, entry in self._procs.items():
            proc = entry["proc"]
            processes.append(
                {
                    "pid": pid,
                    "cmd": entry["cmd"],
                    "running": proc.poll() is None,
                }
            )
        return {"processes": processes}

    def cmd_kill(self, pid):
        try:
            entry = self._procs.get(pid)
            if entry is None:
                return {"killed": False, "error": f"No process with pid {pid}"}
            entry["proc"].kill()
            return {"killed": True, "error": None}
        except Exception as e:
            return {"killed": False, "error": str(e)}

    def cmd_send_stdin(self, pid, data, eof=False):
        try:
            entry = self._procs.get(pid)
            if entry is None:
                return {"error": f"No process with pid {pid}"}
            proc = entry["proc"]
            if proc.stdin is None:
                # stdin was detached to /dev/null (default). Fail loudly
                # instead of silently dropping the data.
                return {
                    "error": (
                        f"process {pid} was not started with stdin enabled; "
                        "start it with stdin=True to use send_stdin"
                    )
                }
            if proc.stdin.closed:
                return {"error": f"stdin of process {pid} is already closed"}
            if data:
                proc.stdin.write(data.encode())
                proc.stdin.flush()
            if eof:
                # Close the write end so the child sees EOF on its next
                # read(). Required for processes that only act on EOF
                # (cat, sort, wc, python3 -, ...).
                proc.stdin.close()
            return {"error": None}
        except Exception as e:
            return {"error": str(e)}

    # ── persistent bash session methods ──────────────────────────────

    _BASH_SENTINEL = "AKSHELL_SENTINEL"

    def bash_init(self, session_id, shell="/bin/bash"):
        """Start a persistent bash process for the given session."""
        import fcntl
        import os
        import pty
        import subprocess
        import threading
        import time

        if session_id in self._bash_sessions:
            return {"error": f"session {session_id} already exists"}

        try:
            master_fd, slave_fd = pty.openpty()
        except Exception as e:
            return {"error": f"pty.openpty failed: {e}"}

        # Clear LD_LIBRARY_PATH to avoid glibc conflicts
        env = os.environ.copy()
        env.pop("LD_LIBRARY_PATH", None)
        env.pop("LD_PRELOAD", None)

        try:
            proc = subprocess.Popen(
                [shell, "--norc", "--noprofile"],
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                close_fds=True,
                preexec_fn=os.setsid,
                env=env,
            )
        except Exception as e:
            os.close(slave_fd)
            os.close(master_fd)
            return {"error": f"subprocess.Popen failed: {e}"}

        os.close(slave_fd)
        flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
        fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        # Wait briefly to check if process exits immediately
        time.sleep(0.1)
        if proc.poll() is not None:
            # Process exited immediately, read error output
            try:
                output = os.read(master_fd, 4096).decode("utf-8", errors="replace")
            except OSError:
                output = ""
            os.close(master_fd)
            return {
                "error": f"bash exited immediately with code {proc.returncode}: {output}"
            }

        self._bash_sessions[session_id] = {
            "proc": proc,
            "master_fd": master_fd,
            "lock": threading.Lock(),
            "result": None,
            "result_event": threading.Event(),
            "collector_thread": None,
        }
        # Drain initial prompt
        self._bash_drain(session_id, 0.5)
        return {"error": None}

    def bash_submit(self, session_id, command, timeout=60):
        """Submit a command to the persistent bash. Returns immediately."""
        import threading

        session = self._bash_sessions.get(session_id)
        if session is None:
            return {"error": f"session {session_id} not found"}

        # Clear previous result
        session["result"] = None
        session["result_event"].clear()

        sentinel = f"{self._BASH_SENTINEL}_{id(command) & 0xFFFFFFFF}"
        wrapped = f"{command}\necho '{sentinel}'_$?\n"

        with session["lock"]:
            import os

            try:
                os.write(session["master_fd"], wrapped.encode())
            except OSError as e:
                session["result"] = {
                    "stdout": "",
                    "stderr": str(e),
                    "exit_code": -1,
                }
                session["result_event"].set()
                return {"error": str(e)}

        # Start collector thread to read output until sentinel
        t = threading.Thread(
            target=self._bash_collect,
            args=(session_id, sentinel, timeout),
            daemon=True,
        )
        session["collector_thread"] = t
        t.start()
        return {"error": None}

    def bash_poll(self, session_id, wait_timeout=10):
        """Long-poll for command result. Waits up to wait_timeout seconds."""
        session = self._bash_sessions.get(session_id)
        if session is None:
            return {"status": "error", "error": f"session {session_id} not found"}

        session["result_event"].wait(timeout=wait_timeout)

        if session["result"] is not None:
            result = session["result"]
            return {
                "status": "done",
                "stdout": result["stdout"],
                "stderr": result["stderr"],
                "exit_code": result["exit_code"],
            }
        return {"status": "running"}

    def bash_destroy(self, session_id):
        """Destroy a bash session."""
        import os
        import signal

        session = self._bash_sessions.pop(session_id, None)
        if session is None:
            return {"error": f"session {session_id} not found"}
        try:
            os.killpg(os.getpgid(session["proc"].pid), signal.SIGKILL)
        except Exception:
            try:
                session["proc"].kill()
            except Exception:
                pass
        try:
            session["proc"].wait(timeout=5)
        except Exception:
            pass
        try:
            os.close(session["master_fd"])
        except Exception:
            pass
        # Unblock any waiting poll
        session["result_event"].set()
        return {"error": None}

    def _bash_collect(self, session_id, sentinel, timeout):
        """Background thread: read pty output until sentinel appears or timeout."""
        import errno
        import os
        import re
        import select
        import signal
        import time

        session = self._bash_sessions.get(session_id)
        if session is None:
            return

        buf = b""
        deadline = time.time() + timeout
        sentinel_re = re.compile(rf"{re.escape(sentinel)}_(\d+)")
        read_count = 0
        proc = session["proc"]

        while time.time() < deadline:
            # Check if bash process is still alive
            if proc.poll() is not None:
                # Process exited, read remaining output and return
                try:
                    while True:
                        ready, _, _ = select.select([session["master_fd"]], [], [], 0.1)
                        if ready:
                            chunk = os.read(session["master_fd"], 4096)
                            if chunk:
                                buf += chunk
                                read_count += 1
                            else:
                                break
                        else:
                            break
                except OSError:
                    pass

                text = buf.decode("utf-8", errors="replace")
                parts = text.split("\n", 1)
                output = parts[1] if len(parts) > 1 else text
                output = re.sub(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])", "", output)
                output = output.replace("\r\n", "\n").replace("\r", "\n")
                lines = [
                    ln
                    for ln in output.split("\n")
                    if sentinel not in ln and not re.match(r"[\w.-]+[#$]\s", ln)
                ]
                output = "\n".join(lines).strip("\n")

                session["result"] = {
                    "stdout": output,
                    "stderr": f"bash process exited with code {proc.returncode}",
                    "exit_code": -1,
                }
                session["result_event"].set()
                return

            try:
                ready, _, _ = select.select(
                    [session["master_fd"]],
                    [],
                    [],
                    min(0.1, max(0.0, deadline - time.time())),
                )
                if ready:
                    chunk = os.read(session["master_fd"], 4096)
                    if chunk:
                        buf += chunk
                        read_count += 1
                        text = buf.decode("utf-8", errors="replace")
                        m = sentinel_re.search(text)
                        if m:
                            rc = int(m.group(1))
                            raw = text[: m.start()]
                            # Skip first line (command echo from pty)
                            parts = raw.split("\n", 1)
                            output = parts[1].rstrip("\r\n") if len(parts) > 1 else ""
                            # Filter ANSI escapes
                            output = re.sub(
                                r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])",
                                "",
                                output,
                            )
                            output = output.replace("\r\n", "\n").replace("\r", "\n")
                            lines = [
                                ln
                                for ln in output.split("\n")
                                if sentinel not in ln
                                and not re.match(r"[\w.-]+[#$]\s", ln)
                            ]
                            output = "\n".join(lines).strip("\n")
                            session["result"] = {
                                "stdout": output,
                                "stderr": "",
                                "exit_code": rc,
                            }
                            session["result_event"].set()
                            return
            except OSError as e:
                if e.errno == errno.EIO:
                    break
                raise

        # Timed out — interrupt foreground process group
        # Read remaining output first
        try:
            while True:
                ready, _, _ = select.select([session["master_fd"]], [], [], 0.1)
                if ready:
                    chunk = os.read(session["master_fd"], 4096)
                    if chunk:
                        buf += chunk
                    else:
                        break
                else:
                    break
        except OSError:
            pass

        # Parse the read output
        text = buf.decode("utf-8", errors="replace")
        # Skip the first line (command echo)
        parts = text.split("\n", 1)
        output = parts[1] if len(parts) > 1 else text
        # Filter ANSI escape sequences
        output = re.sub(
            r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])",
            "",
            output,
        )
        output = output.replace("\r\n", "\n").replace("\r", "\n")
        lines = [
            ln
            for ln in output.split("\n")
            if sentinel not in ln and not re.match(r"[\w.-]+[#$]\s", ln)
        ]
        output = "\n".join(lines).strip("\n")

        if session["proc"].poll() is None:
            try:
                os.killpg(os.getpgid(session["proc"].pid), signal.SIGINT)
            except Exception:
                pass
            try:
                os.write(session["master_fd"], b"\n")
                self._bash_drain(session_id, 0.5)
            except Exception:
                pass
        session["result"] = {
            "stdout": output,
            "stderr": f"Command timed out after {timeout}s",
            "exit_code": -1,
        }
        session["result_event"].set()

    def _bash_drain(self, session_id, timeout=0.2):
        """Read and discard pending pty output."""
        import os
        import select
        import time

        session = self._bash_sessions.get(session_id)
        if session is None:
            return
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                ready, _, _ = select.select([session["master_fd"]], [], [], 0.05)
                if ready:
                    os.read(session["master_fd"], 4096)
            except OSError:
                break

    # ── tunnel methods ────────────────────────────────────────────────

    def start_tunnel_server(self, ws_port=8765, http_port=8766):
        """Start TunnelServer in a background thread within this sandbox instance.

        Port A (ws_port): WebSocket endpoint for TunnelClient connection.
        Port B (http_port): HTTP proxy for sandbox code to call.
        """
        import asyncio
        import socket as _socket
        import threading
        import time

        from yr.sandbox.tunnel_server import TunnelServer

        def _run():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            server = TunnelServer(ws_port=ws_port, http_port=http_port)
            loop.run_until_complete(server.start())
            loop.run_forever()

        t = threading.Thread(target=_run, name="tunnel-server", daemon=True)
        t.start()
        # Wait until both ports are actually bound (up to 5s)
        deadline = time.time() + 5.0
        for port in (ws_port, http_port):
            while time.time() < deadline:
                try:
                    _socket.create_connection(("127.0.0.1", port), timeout=0.1).close()
                    break
                except OSError:
                    time.sleep(0.1)
        return {"error": None}

    # ── lifecycle methods ──────────────────────────────────────────────

    def ping(self):
        return {"status": "ok"}

    def get_info(self):
        return {
            "state": "running",
            "cwd": self._cwd,
        }
