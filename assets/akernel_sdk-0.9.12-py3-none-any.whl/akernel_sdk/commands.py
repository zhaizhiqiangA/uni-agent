import logging
import random
import time
from typing import Dict, List, Optional, Union

import yr

from .types import CommandResult, YR_GET_DEFAULT_TIMEOUT, YR_GET_TIMEOUT_BUFFER

logger = logging.getLogger(__name__)

# When timeout exceeds this threshold, Commands.run() automatically switches
# to a start+poll loop so that each yr RPC stays short, avoiding intermediate
# component (e.g. VIP) timeout resets.
_POLL_THRESHOLD = 30  # seconds
_POLL_INTERVAL = 10  # seconds per poll RPC


def _poll_pid_until_done(instance, pid: int, timeout: int) -> "CommandResult":
    """Poll a running pid until it finishes or the wall-clock deadline expires.

    Uses monotonic-clock deadline as the single source of truth for timeout.
    RPC failures are logged and retried without backoff; the deadline naturally
    closes the loop if the backend is persistently broken.
    """
    deadline = time.monotonic() + timeout

    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break

        jittered = _POLL_INTERVAL * (0.7 + random.random() * 0.6)
        poll_wait = min(jittered, remaining)
        rpc_timeout = max(poll_wait + YR_GET_TIMEOUT_BUFFER, YR_GET_DEFAULT_TIMEOUT)

        try:
            poll_result = yr.get(
                instance.cmd_poll.invoke(pid=pid, wait_timeout=poll_wait),
                timeout=rpc_timeout,
            )
        except Exception as e:
            logger.warning(
                "cmd_poll RPC failed (pid=%d, remaining=%.1fs): %s",
                pid,
                remaining,
                e,
            )
            continue

        status = poll_result["status"]
        if status == "done":
            return CommandResult(
                stdout=poll_result["stdout"],
                stderr=poll_result["stderr"],
                exit_code=poll_result["exit_code"],
            )
        if status == "error":
            return CommandResult(
                stdout="",
                stderr=poll_result.get("error", "Unknown error"),
                exit_code=-1,
            )
        # status == "running" → loop

    try:
        yr.get(
            instance.cmd_kill.invoke(pid=pid),
            timeout=YR_GET_DEFAULT_TIMEOUT,
        )
    except Exception as e:
        logger.warning("cmd_kill after timeout failed (pid=%d): %s", pid, e)

    return CommandResult(
        stdout="",
        stderr=f"Command timed out after {timeout} seconds",
        exit_code=-1,
    )


class CommandHandle:
    """Handle for a background process running in the sandbox."""

    def __init__(self, pid: int, instance):
        self.pid = pid
        self._instance = instance

    def wait(self, timeout: Optional[int] = None) -> CommandResult:
        if timeout is None:
            # Unbounded wait: fall back to a single long RPC.
            result = yr.get(
                self._instance.cmd_wait.invoke(pid=self.pid, timeout=None),
                timeout=-1,
            )
            return CommandResult(
                stdout=result["stdout"],
                stderr=result["stderr"],
                exit_code=result["exit_code"],
            )
        return _poll_pid_until_done(self._instance, self.pid, timeout)

    def kill(self) -> bool:
        result = yr.get(self._instance.cmd_kill.invoke(pid=self.pid))
        return result["killed"]

    def send_stdin(self, data: str, eof: bool = False) -> None:
        """Write *data* to the process's stdin.

        :param eof: when True, close stdin after writing so the process sees
            EOF on its next read. Required for processes that only act on EOF
            (cat, sort, wc, python3 -, ...). Pass ``data=""`` with
            ``eof=True`` to close stdin without sending anything.
        """
        result = yr.get(
            self._instance.cmd_send_stdin.invoke(pid=self.pid, data=data, eof=eof)
        )
        if result.get("error"):
            raise RuntimeError(f"Failed to send stdin: {result['error']}")

    def close_stdin(self) -> None:
        """Close the process's stdin so it sees EOF."""
        self.send_stdin("", eof=True)


class Commands:
    """Client-side wrapper for command execution on the remote sandbox."""

    def __init__(self, instance):
        self._instance = instance

    def run(
        self,
        cmd: str,
        background: bool = False,
        envs: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        timeout: int = 60,
        stdin: bool = False,
    ) -> Union[CommandResult, CommandHandle]:
        """Execute *cmd* on the sandbox.

        :param stdin: only honored with ``background=True``. When True the
            background process keeps an open stdin PIPE so ``send_stdin`` can
            feed it input. Default False detaches stdin to /dev/null — an open
            PIPE with no writer never reaches EOF, so interactive prompts
            (e.g. apt/debconf) would otherwise block forever on read().
        """
        if background:
            result = yr.get(
                self._instance.cmd_start.invoke(
                    cmd=cmd, envs=envs, cwd=cwd, want_stdin=stdin
                )
            )
            if result.get("error"):
                raise RuntimeError(f"Failed to start command: {result['error']}")
            return CommandHandle(result["pid"], self._instance)

        # For long timeouts, use start+poll loop so each RPC stays short
        # and avoids intermediate component (e.g. VIP) timeout resets.
        if timeout > _POLL_THRESHOLD:
            return self._run_with_poll(cmd, envs=envs, cwd=cwd, timeout=timeout)

        rpc_timeout = max(timeout + YR_GET_TIMEOUT_BUFFER, YR_GET_DEFAULT_TIMEOUT)
        result = yr.get(
            self._instance.cmd_run.invoke(cmd=cmd, envs=envs, cwd=cwd, timeout=timeout),
            timeout=rpc_timeout,
        )
        return CommandResult(
            stdout=result["stdout"],
            stderr=result["stderr"],
            exit_code=result["exit_code"],
        )

    def _run_with_poll(
        self,
        cmd: str,
        envs: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        timeout: int = 60,
    ) -> CommandResult:
        """Execute a command using start + poll loop for long-running commands."""
        result = yr.get(self._instance.cmd_start.invoke(cmd=cmd, envs=envs, cwd=cwd))
        if result.get("error"):
            raise RuntimeError(f"Failed to start command: {result['error']}")
        pid = result["pid"]
        return _poll_pid_until_done(self._instance, pid, timeout)

    def list(self) -> List[dict]:
        result = yr.get(self._instance.cmd_list.invoke())
        return result["processes"]

    def kill(self, pid: int) -> bool:
        result = yr.get(self._instance.cmd_kill.invoke(pid=pid))
        return result["killed"]

    def send_stdin(self, pid: int, data: str, eof: bool = False) -> None:
        """Write *data* to the stdin of process *pid*.

        :param eof: when True, close stdin after writing so the process sees
            EOF on its next read. Required for processes that only act on EOF
            (cat, sort, wc, python3 -, ...). Pass ``data=""`` with
            ``eof=True`` to close stdin without sending anything.
        """
        result = yr.get(
            self._instance.cmd_send_stdin.invoke(pid=pid, data=data, eof=eof)
        )
        if result.get("error"):
            raise RuntimeError(f"Failed to send stdin: {result['error']}")

    def close_stdin(self, pid: int) -> None:
        """Close the stdin of process *pid* so it sees EOF."""
        self.send_stdin(pid, "", eof=True)
