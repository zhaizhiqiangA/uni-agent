"""Shell — a persistent shell session backed by yr RPC."""
import os
import asyncio
import logging
from typing import Optional

import yr

from ..types import CommandResult

logger = logging.getLogger(__name__)

# yr.get timeout for each RPC call (must be > bash_poll wait_timeout)
_RPC_TIMEOUT = int(os.environ.get("AKERNEL_RPC_TIMEOUT", 60))
# Long-poll wait inside the container (seconds)
_POLL_WAIT = int(os.environ.get("AKERNEL_POLL_WAIT", 10))


class Shell:
    """A persistent shell session backed by yr RPC to the sandbox container.

    Each Shell corresponds to a bash (or other shell) process running inside
    the container. State (cwd, env vars, shell functions) is preserved across
    ``run()`` calls.

    Communication uses short-lived yr RPC calls (submit + long-poll), so it
    is immune to VIP / gateway idle-connection timeouts.

    **stdout / stderr note:** Since the shell session uses a pty, stderr is
    merged into stdout. ``CommandResult.stderr`` is always an empty string
    (except for timeout / error messages).

    Instances are created via :meth:`Shells.create`, not directly.
    """

    def __init__(self, instance, session_id: str, sandbox_id: str = ""):
        self._instance = instance
        self._session_id = session_id
        self._sandbox_id = sandbox_id
        self._lock = asyncio.Lock()

    @property
    def session_id(self) -> str:
        return self._session_id

    # ── public API ─────────────────────────────────────────────────────

    async def run(
        self,
        cmd: str,
        envs: Optional[dict] = None,
        cwd: Optional[str] = None,
        timeout: int = 60,
    ) -> CommandResult:
        """Execute *cmd* in the persistent shell and return the result.

        :param cmd: Command to execute.
        :param envs: One-shot environment variables (injected via ``export``
            prefix in a subshell, does not persist to subsequent calls).
        :param cwd: One-shot working directory (injected via ``cd`` prefix
            in a subshell, does not persist to subsequent calls).
        :param timeout: Maximum seconds to wait for the command to finish.
            On timeout the command is interrupted with SIGINT and the shell
            remains usable for subsequent calls.
        :return: :class:`CommandResult` with stdout, stderr, and exit_code.
        """
        async with self._lock:
            effective_cmd = self._build_cmd(cmd, envs=envs, cwd=cwd)

            # 1. Submit command — returns immediately
            sid = self._session_id
            submit_result = await asyncio.to_thread(
                lambda: yr.get(
                    self._instance.bash_submit.invoke(
                        session_id=sid,
                        command=effective_cmd,
                        timeout=timeout,
                    ),
                    timeout=_RPC_TIMEOUT,
                )
            )
            if submit_result.get("error"):
                logger.warning(
                    f"Shell.run submit failed: sandbox={self._sandbox_id} "
                    f"session={sid} error={submit_result['error']}"
                )
                return CommandResult(
                    stdout="",
                    stderr=submit_result["error"],
                    exit_code=-1,
                )

            # 2. Long-poll loop — each RPC waits up to _POLL_WAIT seconds
            deadline = asyncio.get_event_loop().time() + timeout + _POLL_WAIT + 5
            while asyncio.get_event_loop().time() < deadline:
                poll_result = await asyncio.to_thread(
                    lambda: yr.get(
                        self._instance.bash_poll.invoke(
                            session_id=sid,
                            wait_timeout=_POLL_WAIT,
                        ),
                        timeout=_RPC_TIMEOUT,
                    )
                )
                if poll_result["status"] == "done":
                    return CommandResult(
                        stdout=poll_result.get("stdout", ""),
                        stderr=poll_result.get("stderr", ""),
                        exit_code=poll_result.get("exit_code", 0),
                    )
                if poll_result["status"] == "error":
                    return CommandResult(
                        stdout="",
                        stderr=poll_result.get("error", "unknown error"),
                        exit_code=-1,
                    )
                # status == "running", continue polling

            return CommandResult(
                stdout="",
                stderr=f"Command timed out after {timeout}s",
                exit_code=-1,
            )

    async def kill(self) -> None:
        """Destroy this shell session."""
        sid = self._session_id
        try:
            await asyncio.to_thread(
                lambda: yr.get(
                    self._instance.bash_destroy.invoke(session_id=sid),
                    timeout=_RPC_TIMEOUT,
                )
            )
        except Exception as e:
            logger.warning(
                f"Shell.kill failed: sandbox={self._sandbox_id} session={sid}: {e}"
            )

    def close(self) -> None:
        """Synchronously destroy the shell session.

        Safe to call from non-async contexts (``Sandbox.kill()``, ``__del__``).
        """
        sid = self._session_id
        try:
            yr.get(
                self._instance.bash_destroy.invoke(session_id=sid),
                timeout=_RPC_TIMEOUT,
            )
        except Exception as e:
            logger.warning(
                f"Shell.close failed: sandbox={self._sandbox_id} session={sid}: {e}"
            )

    # ── internal helpers ───────────────────────────────────────────────

    @staticmethod
    def _build_cmd(
        cmd: str,
        envs: Optional[dict] = None,
        cwd: Optional[str] = None,
    ) -> str:
        """Wrap *cmd* with optional cd/export prefixes.

        When cwd or envs are provided, the command runs in a subshell so
        that the cwd/env changes do not persist to subsequent calls.
        """
        if not cwd and not envs:
            return cmd
        parts = []
        if cwd:
            parts.append(f"cd {cwd}")
        if envs:
            for k, v in envs.items():
                parts.append(f"export {k}='{v}'")
        parts.append(cmd)
        return "( " + " && ".join(parts) + " )"
