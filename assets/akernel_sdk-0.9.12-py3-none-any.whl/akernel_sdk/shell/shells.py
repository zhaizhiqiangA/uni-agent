"""Shells — factory for creating persistent Shell sessions via yr RPC."""

import asyncio
from typing import Dict, List, Optional

import yr

from .shell import Shell, _RPC_TIMEOUT


class Shells:
    """Factory for creating :class:`Shell` instances.

    Accessible as ``sandbox.shells``. Each :meth:`create` call starts a new
    persistent bash process inside the container via yr RPC and returns a
    :class:`Shell` bound to that session.
    """

    def __init__(self, instance, sandbox_id: str = ""):
        self._instance = instance
        self._sandbox_id = sandbox_id
        self._shells: List[Shell] = []
        self._counter = 0

    async def create(
        self,
        cwd: Optional[str] = None,
        envs: Optional[Dict[str, str]] = None,
        shell: str = "/bin/bash",
        timeout: int = _RPC_TIMEOUT,
    ) -> Shell:
        """Create a new persistent shell session.

        The bash process is started immediately inside the container via
        yr RPC. If the call fails, an exception is raised right away.

        :param cwd: Initial working directory (set via ``cd`` after init).
        :param envs: Initial environment variables (set via ``export`` after init).
        :param shell: Shell binary, default ``/bin/bash``. Also accepts
            ``/bin/sh``, ``/bin/zsh``, ``/usr/bin/fish``, etc.
        :param timeout: yr RPC timeout in seconds for shell initialization.
            Defaults to ``_RPC_TIMEOUT`` when not provided. If ``cwd`` or
            ``envs`` is set, this timeout is also used for the initial
            shell setup command.
        :return: A connected :class:`Shell` instance.
        """
        self._counter += 1
        session_id = f"sh_{self._counter}"

        inst = self._instance
        result = await asyncio.to_thread(
            lambda: yr.get(
                inst.bash_init.invoke(session_id=session_id, shell=shell),
                timeout=timeout,
            )
        )
        if result.get("error"):
            raise RuntimeError(f"Failed to create shell session: {result['error']}")

        sh = Shell(self._instance, session_id, sandbox_id=self._sandbox_id)
        self._shells.append(sh)

        # Apply initial cwd / envs if provided.
        if cwd or envs:
            init_parts = []
            if cwd:
                init_parts.append(f"cd {cwd}")
            if envs:
                for k, v in envs.items():
                    init_parts.append(f"export {k}='{v}'")
            await sh.run(" && ".join(init_parts), timeout=timeout)

        return sh

    def close(self) -> None:
        """Synchronously close all shell sessions.

        Called by ``Sandbox.kill()`` and ``Sandbox.__del__``.
        """
        for sh in self._shells:
            sh.close()
        self._shells.clear()
