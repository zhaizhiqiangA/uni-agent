import json
import logging
import os
import ssl
import urllib.request
from typing import Any, Dict, List, Optional, Union

import yr
from yr.config import PortForwarding
from yr.runtime_holder import global_runtime
from yr.sandbox.sandbox import _get_gateway_host, _sanitize_instance_id

logger = logging.getLogger(__name__)

_traefik_internal_ip_cache: Optional[str] = None


def _parse_host_port(address: str) -> tuple[str, str]:
    """Parse host and port from an address string like '1.2.3.4:8888'."""
    parts = address.rsplit(":", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return parts[0], "8888"


def _get_traefik_internal_ip(gateway: str) -> tuple[str, str]:
    """Fetch traefik pod IP from /internal-stats endpoint, with module-level cache.

    The /internal-stats route is registered on the TLS frontend (websecure)
    entrypoint only, so the lookup always targets AKERNEL_SERVER_ADDRESS. The
    returned port still comes from the caller-supplied gateway, so the final
    URL points at the right entrypoint (e.g. the web port for port forwarding).

    Returns (pod_ip, gateway_port) tuple.
    """
    global _traefik_internal_ip_cache
    _, gw_port = _parse_host_port(gateway)
    if _traefik_internal_ip_cache is not None:
        return _traefik_internal_ip_cache, gw_port

    server = os.environ.get("AKERNEL_SERVER_ADDRESS", "").strip()
    if not server:
        raise RuntimeError(
            "AKERNEL_SERVER_ADDRESS must be set to look up traefik pod IP via /internal-stats"
        )
    url = f"https://{server}/internal-stats"
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    with urllib.request.urlopen(url, timeout=5, context=ctx) as resp:
        data = json.loads(resp.read())
    pod_ip = data["pod_ip"]
    _traefik_internal_ip_cache = pod_ip
    return pod_ip, gw_port


from .commands import Commands
from .filesystem import Filesystem
from .instance import _SandboxInstance
from .shell import Shells
from .types import Mount, SandboxInfo


class Sandbox:
    """E2B-style sandbox API for AKernel.

    Provides file system operations, command execution, persistent shell
    sessions, and lifecycle management through a clean, high-level interface.

    Usage::

        with Sandbox(image="python:3.12-slim", cpu=2000, memory=4096) as sb:
            sb.files.write("/tmp/hello.txt", "hello world")
            result = sb.commands.run("cat /tmp/hello.txt")
            print(result.stdout)

            # Persistent shell
            sh = await sb.shells.create(cwd="/tmp")
            await sh.run("export FOO=bar")
            result = await sh.run("echo $FOO")  # → bar
    """

    def __init__(
        self,
        image: Optional[str] = None,
        cpu: int = 1000,
        memory: int = 4096,
        cpu_limit: int = 0,
        mem_limit: int = 0,
        idle_timeout: int = 300,
        env: Optional[Dict[str, str]] = None,
        name: Optional[str] = None,
        cwd: Optional[str] = None,
        port_forwardings: Optional[List[Union[int, PortForwarding]]] = None,
        mounts: Optional[List[Mount]] = None,
        upstream: Optional[str] = None,
        proxy_port: int = 8766,
        detached: bool = False,
        extra_config: Optional[Dict[str, Any]] = None,
    ):
        """Create a new sandbox instance.

        Args:
            image: Container image to use (e.g. ``"python:3.12-slim"``).
            cpu: CPU scheduling request in milli-cores (default 1000).
                Determines node selection and resource deduction.
            memory: Memory scheduling request in MB (default 4096).
                Determines node selection and resource deduction.
            cpu_limit: CPU cgroup limit in milli-cores.
                ``0`` = not set (container limit equals *cpu*, default);
                ``>0`` = explicit limit (must be >= *cpu*).
                Allows the container to burst beyond its scheduling request.
            mem_limit: Memory cgroup limit in MB.
                ``0`` = not set (container limit equals *memory*, default);
                ``>0`` = explicit limit (must be >= *memory*).
                Allows the container to burst beyond its scheduling request.
            idle_timeout: Seconds before idle sandbox is reclaimed (default 300).
            env: Environment variables to set in the sandbox.
            name: Logical name for the sandbox instance.
            cwd: Working directory inside the sandbox.
            port_forwardings: Ports to forward from the sandbox.
            upstream: Upstream URL for reverse tunnel.
            proxy_port: Proxy port for reverse tunnel (default 8766).
            detached: If True, the underlying yr instance uses
                ``lifecycle=detached`` so the sandbox keeps running after the
                creating Python process exits. ``kill()`` / ``__exit__`` /
                ``__del__`` then skip terminating the remote instance; call
                :meth:`Sandbox.delete` (or wait for ``idle_timeout``) to
                reclaim it.
            extra_config: Extra sandbox-side configuration forwarded to
                sandboxd as ``StartRequest.ExtraConfig`` (a JSON-encoded
                string). Supported keys mirror the Go ``ExtraConfig`` struct
                in ``src/node/sandboxd/server/server.go``:

                - ``blockNetwork`` (bool): block all egress.
                - ``cidrAllowlist`` (str): comma-separated CIDR allowlist.
                - ``networkStack`` (str): in-sandbox network stack —
                  ``"plugin"`` (default, third-party TLDK/DPDK) or
                  ``"netstack"`` (gVisor native netstack).
        """
        from .sandbox import ensure_yr_init

        ensure_yr_init()
        opt = yr.InvokeOptions()
        opt.idle_timeout = idle_timeout
        opt.cpu = cpu
        opt.memory = memory
        opt.cpu_limit = cpu_limit
        opt.mem_limit = mem_limit
        if image:
            opt.custom_extensions["rootfs"] = json.dumps(
                {
                    "runtime": "runsc",
                    "type": "image",
                    "readonly": False,
                    "imageurl": image,
                }
            )
        if detached:
            opt.custom_extensions["lifecycle"] = "detached"
        self._detached = detached
        if env:
            opt.env_vars = env
        if mounts:
            opt.custom_extensions["mounts"] = json.dumps([m.to_dict() for m in mounts])
        if extra_config:
            opt.custom_extensions["extra_config"] = json.dumps(extra_config)
        opt.namespace = "akernel"
        if name:
            opt.name = name

        self._forwarded_ports: set = set()
        if port_forwardings:
            pf_list = []
            for pf in port_forwardings:
                if isinstance(pf, int):
                    pf_list.append(PortForwarding(port=pf, protocol="TCP"))
                    self._forwarded_ports.add(pf)
                else:
                    pf_list.append(pf)
                    self._forwarded_ports.add(pf.port)
            opt.port_forwardings = pf_list

        # Reverse tunnel: register tunnel WebSocket port with Traefik
        self._tunnel_client = None
        self._proxy_port = proxy_port
        if upstream is not None:
            tunnel_port = proxy_port - 1
            tunnel_pf = PortForwarding(port=tunnel_port)
            opt.port_forwardings = (
                list(opt.port_forwardings) if opt.port_forwardings else []
            ) + [tunnel_pf]

        self._image = image
        self._cpu = cpu
        self._memory = memory

        self._instance = _SandboxInstance.options(opt).invoke(cwd=cwd)
        # Wait for the instance to be ready
        yr.get(self._instance.ping.invoke())

        # Reverse tunnel: start TunnelServer in sandbox, connect TunnelClient locally
        if upstream is not None:
            tunnel_port = proxy_port - 1
            yr.get(self._instance.start_tunnel_server.invoke(tunnel_port, proxy_port))
            # Build WebSocket URL via Traefik gateway
            gateway_host = _get_gateway_host()
            safe_id = _sanitize_instance_id(
                global_runtime.get_runtime().get_real_instance_id(
                    self._instance.instance_id
                )
            )
            gateway = os.environ.get("YR_GATEWAY_ADDRESS", "").strip()
            if not gateway:
                gateway = os.environ.get("YR_SERVER_ADDRESS", "").strip()
            tunnel_ws_url = f"ws://{gateway}/{safe_id}/{tunnel_port}"
            # Start local TunnelClient
            from yr.sandbox.tunnel_client import TunnelClient

            self._tunnel_client = TunnelClient(upstream)
            if self._tunnel_client.start(tunnel_ws_url, timeout=10.0):
                logger.info("TunnelClient connected successfully")
            else:
                logger.warning(
                    "TunnelClient connection timeout, will retry in background"
                )

        self._files = Filesystem(self._instance, instance_id=self.id)
        self._commands = Commands(self._instance)
        self._shells = Shells(self._instance, sandbox_id=self.id)

    @property
    def files(self) -> Filesystem:
        return self._files

    @property
    def commands(self) -> Commands:
        return self._commands

    @property
    def shells(self) -> Shells:
        """Factory for creating persistent shell sessions.

        Usage::

            sh = await sb.shells.create(cwd="/testbed")
            result = await sh.run("pwd")  # → /testbed
        """
        return self._shells

    @property
    def id(self) -> str:
        """Real (physical) instance ID, consistent with ak list output."""
        return global_runtime.get_runtime().get_real_instance_id(
            self._instance.instance_id
        )

    @property
    def sandbox_id(self) -> str:
        return self.id

    def get_port_url(self, port: int, *, internal: bool = False) -> str:
        """Get the tunnel URL for a forwarded port.

        Currently only HTTP forwarding is supported.

        Args:
            port: The port number configured in port_forwardings.
            internal: If True, resolve the traefik pod IP via /internal-stats
                and return a direct URL bypassing the VIP.

        Returns:
            Tunnel URL: http://{gateway}/{real_instance_id}/{port}
            or (internal): http://{pod_ip}:{port}/{real_instance_id}/{port}

        Raises:
            ValueError: If port is not in port_forwardings or gateway address is not set.
        """
        if port not in self._forwarded_ports:
            raise ValueError(
                f"Port {port} is not in forwarded ports: {self._forwarded_ports}"
            )
        gateway = os.environ.get("YR_GATEWAY_ADDRESS", "").strip()
        if not gateway:
            gateway = os.environ.get("YR_SERVER_ADDRESS", "").strip()
        if not gateway:
            raise ValueError(
                "YR_GATEWAY_ADDRESS or YR_SERVER_ADDRESS must be set for tunnel URL"
            )
        real_id = global_runtime.get_runtime().get_real_instance_id(
            self._instance.instance_id
        )
        if internal:
            pod_ip, gw_port = _get_traefik_internal_ip(gateway)
            return f"http://{pod_ip}:{gw_port}/{real_id}/{port}"
        return f"http://{gateway}/{real_id}/{port}"

    def get_tunnel_url(self) -> str:
        """Return the internal HTTP proxy URL for sandbox code to call.

        Returns:
            str: e.g. "http://127.0.0.1:8766"
        Raises:
            RuntimeError: if no upstream was configured.
        """
        if self._tunnel_client is None:
            raise RuntimeError("No upstream configured. Pass upstream= to Sandbox().")
        return f"http://127.0.0.1:{self._proxy_port}"

    def is_running(self) -> bool:
        try:
            yr.get(self._instance.ping.invoke())
            return True
        except Exception:
            return False

    def get_info(self) -> SandboxInfo:
        result = yr.get(self._instance.get_info.invoke())
        return SandboxInfo(
            sandbox_id=self.sandbox_id,
            state=result.get("state", "unknown"),
            cpu=self._cpu,
            memory=self._memory,
            image=self._image,
        )

    def kill(self) -> None:
        if self._tunnel_client is not None:
            self._tunnel_client.stop()
            self._tunnel_client = None
        self._shells.close()
        if not self._detached:
            self._instance.terminate()

    @classmethod
    def delete(cls, name: str, namespace: str = "akernel") -> None:
        """Terminate a named (typically detached) sandbox by logical name.

        Companion to ``Sandbox(name=..., detached=True)`` — provides a pure
        Python path to reclaim a detached sandbox without going through
        ``tools/ak delete`` (which requires sudo + docker).

        Args:
            name: Logical sandbox name passed to ``Sandbox(name=...)``.
            namespace: yr namespace (defaults to "akernel", matching the
                namespace used by :class:`Sandbox`).
        """
        from .sandbox import ensure_yr_init

        ensure_yr_init()
        handle = yr.get_instance(name, namespace=namespace)
        handle.terminate(is_sync=True)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.kill()

    def __del__(self):
        try:
            self.kill()
        except Exception:
            pass
